import React from 'react';
import { View } from "react-native"
import { Ionicons } from '@expo/vector-icons';
import { Appbar } from 'react-native-paper';

const Home = () => {
  return(
    <View style={{flex:1}}> Appbar.Header
    
    </View>
  )
}





export default Home;



